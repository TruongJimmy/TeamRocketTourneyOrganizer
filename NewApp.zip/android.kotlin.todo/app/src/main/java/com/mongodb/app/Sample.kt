package com.mongodb.app

import io.realm.RealmList;
import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmField
import io.realm.annotations.Required
import org.bson.types.ObjectId

open class Sample(
    @PrimaryKey @RealmField("_id")
    var id: ObjectId = ObjectId(),
    var _partition: String = ""

): RealmObject()